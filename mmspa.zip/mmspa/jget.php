<h4>Parameters passed to custom script jget.php:</h4>
<p>Function: jget( {url: 'jget.php', params: { number: 2, menu-id: 'main-menu' } </p>
	<p>Results from script: </p>
	<code>
<?php

print_r($_GET);

?>
</code>
